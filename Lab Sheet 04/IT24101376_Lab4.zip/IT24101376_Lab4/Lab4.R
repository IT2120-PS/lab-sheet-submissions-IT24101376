getwd()
setwd("C:\\Users\\IT24101376\\Desktop\\IT24101376_Lab4")
getwd()

branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")

str(branch_data)
head(branch_data)

boxplot(branch_data$Sales,main="Box plot of sales",ylab="Sales",outpch=8,horizontal=TRUE)

cat("Five Number Summary for Advertising:\n")
   print(fivenum(branch_data$Advertising_X2))

 
print(quantile(branch_data$Advertising_X2))

 advertising_iqr <- IQR(branch_data$Advertising_X2)
 cat("\nIQR for Advertising:", advertising_iqr)

 find_outliers <- function(z) {
  q1 <- quantile(z, 0.25)
 q3 <- quantile(z, 0.75)
    iqr <- q3 - q1
       
       lower_bound <- q1 - (1.5 * iqr)
         upper_bound <- q3 + (1.5 * iqr)
        
           outliers <- z[z < lower_bound | z > upper_bound]
          
            if(length(outliers) == 0) {
                 return("No outliers found.")
               } else {
                     return(outliers)
                }
       }
  years_outliers <- find_outliers(branch_data$Years_X3)
  print(years_outliers)
